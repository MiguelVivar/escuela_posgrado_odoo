## Module education_attendances

#### 26.12.2024
#### Version 18.0.1.0.0
##### ADD
- Initial commit for Educational Attendance Management
