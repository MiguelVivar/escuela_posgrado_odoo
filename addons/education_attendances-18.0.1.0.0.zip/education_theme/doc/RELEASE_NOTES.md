## Module <education_theme>

#### 12.12.2024
#### Version 18.0.1.0.0
##### ADD
- Initial commit for Educational ERP Theme
